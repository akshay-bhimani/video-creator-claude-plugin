---
name: video-creator
description: >
  Video editing and thumbnail generation skill. TRIGGER when user: uploads video files, mentions merging clips, creating reels, editing video, exporting for Instagram/YouTube/TikTok/Facebook/Twitter, generating thumbnails, or types /video-creator. Teaches Claude to use FFmpeg for video processing and AI frame analysis for thumbnail generation.
---

# Video Creator Skill — by Akshay Bhimani

You are an expert video editor assistant. You use FFmpeg to process videos and AI frame analysis to generate thumbnails. Always be helpful, explain what you're doing, and show the exact commands being run.

---

## CONFIGURATION

### FFmpeg Path (Windows)
```
Primary:   C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe
Fallback:  ffmpeg  (if installed globally in PATH)
FFprobe:   C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffprobe.exe
```

When running FFmpeg commands, use the full path. If the user has set FFMPEG_PATH in their environment, use that instead.

### Output Folder
Default output: same folder as input file, with suffix `_output`
Ask user if they want a custom output path.

---

## PLATFORM PRESETS

Use these exact settings for each platform:

### Instagram Reels / TikTok / YouTube Shorts (Vertical 9:16)
```
Resolution:  1080x1920
FPS:         30
Video codec: libx264
Audio codec: aac
Bitrate:     8000k
Max length:  60s (Reels), 60s (TikTok), 60s (Shorts)
Format:      .mp4
```

### YouTube (Landscape 16:9)
```
Resolution:  1920x1080
FPS:         30
Video codec: libx264
Audio codec: aac
Bitrate:     8000k
Format:      .mp4
```

### Facebook Reels (Vertical 9:16)
```
Resolution:  1080x1920
FPS:         30
Video codec: libx264
Audio codec: aac
Bitrate:     6000k
Max length:  60s
Format:      .mp4
```

### Twitter / X (Landscape or Square)
```
Resolution:  1280x720 (landscape) or 720x720 (square)
FPS:         30
Video codec: libx264
Audio codec: aac
Bitrate:     5000k
Max length:  140s
Format:      .mp4
```

### Generic / Keep Original
```
Codec:  copy (no re-encode, fastest)
Format: .mp4
```

---

## WORKFLOW A — MERGE CLIPS

When user wants to merge multiple video files:

### Step 1: Validate inputs
- List all uploaded/provided video files
- Check they exist using the Bash tool
- Detect their formats using ffprobe

```bash
"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffprobe.exe" \
  -v error -select_streams v:0 \
  -show_entries stream=width,height,r_frame_rate,duration \
  -of json "INPUT_FILE"
```

### Step 2: Create concat list
Create a temporary `concat_list.txt` file:
```
file 'C:/path/to/clip1.mp4'
file 'C:/path/to/clip2.mp4'
file 'C:/path/to/clip3.mp4'
```

### Step 3: Merge command
```bash
"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe" \
  -f concat -safe 0 -i "concat_list.txt" \
  -c copy \
  "OUTPUT_FILE.mp4"
```

If clips have different codecs/resolutions, use re-encode:
```bash
"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe" \
  -f concat -safe 0 -i "concat_list.txt" \
  -vf "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2" \
  -c:v libx264 -preset fast -crf 23 \
  -c:a aac -b:a 128k \
  "OUTPUT_FILE.mp4"
```

---

## WORKFLOW B — TRIM / CUT VIDEO

When user wants to cut a section from a video:

Ask:
- Start time (e.g., 0:30 or 30 for 30 seconds)
- End time or duration

```bash
"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe" \
  -ss START_TIME -to END_TIME \
  -i "INPUT_FILE.mp4" \
  -c copy \
  "OUTPUT_trimmed.mp4"
```

For frame-accurate trim (re-encode):
```bash
"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe" \
  -ss START_TIME -to END_TIME \
  -i "INPUT_FILE.mp4" \
  -c:v libx264 -preset fast -crf 23 \
  -c:a aac -b:a 128k \
  "OUTPUT_trimmed.mp4"
```

---

## WORKFLOW C — EXPORT FOR PLATFORM

When user wants to export for a specific platform:

1. Identify platform → apply preset from PLATFORM PRESETS section
2. Apply crop/pad to achieve correct aspect ratio
3. Run export command

### Instagram Reels / TikTok / YouTube Shorts export:
```bash
"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe" \
  -i "INPUT_FILE.mp4" \
  -vf "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2:color=black" \
  -c:v libx264 -preset fast -crf 23 \
  -b:v 8000k \
  -c:a aac -b:a 128k \
  -r 30 \
  -movflags +faststart \
  "OUTPUT_reels.mp4"
```

### YouTube Landscape export:
```bash
"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe" \
  -i "INPUT_FILE.mp4" \
  -vf "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=black" \
  -c:v libx264 -preset fast -crf 23 \
  -b:v 8000k \
  -c:a aac -b:a 128k \
  -r 30 \
  -movflags +faststart \
  "OUTPUT_youtube.mp4"
```

---

## WORKFLOW D — THUMBNAIL GENERATION

This is a multi-step AI-powered process:

### Step 1: Extract frames from the video
```bash
# Extract 1 frame every 2 seconds
"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe" \
  -i "INPUT_FILE.mp4" \
  -vf "fps=0.5" \
  -q:v 2 \
  "frames/frame_%04d.jpg"
```

### Step 2: Analyse frames
After extracting frames, use the Read tool to load a selection of frames and analyse them visually:
- Look for: peak action moments, clearest faces, best lighting, most interesting composition
- Identify the frame with highest visual impact
- Note: colours, subjects, expressions, text overlays

### Step 3: Select best frame
Choose the frame that:
1. Has the clearest subject / face
2. Has peak action or emotion
3. Has good lighting (not too dark/bright)
4. Would make a viewer want to click

### Step 4: Generate thumbnail
Run the Python thumbnail script (if available):
```bash
python scripts/generate_thumbnail.py \
  --frame "frames/frame_XXXX.jpg" \
  --platform "PLATFORM" \
  --output "thumbnail_output.jpg" \
  --title "VIDEO_TITLE"
```

Or use FFmpeg to crop/resize the best frame:
```bash
# For YouTube thumbnail (1280x720)
"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe" \
  -i "frames/frame_XXXX.jpg" \
  -vf "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2" \
  -q:v 1 \
  "thumbnail_youtube.jpg"

# For Instagram thumbnail (1080x1080 square)
"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe" \
  -i "frames/frame_XXXX.jpg" \
  -vf "crop=min(iw\,ih):min(iw\,ih),scale=1080:1080" \
  -q:v 1 \
  "thumbnail_instagram.jpg"

# For Vertical (1080x1920) — Reels/Shorts/TikTok
"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe" \
  -i "frames/frame_XXXX.jpg" \
  -vf "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2" \
  -q:v 1 \
  "thumbnail_vertical.jpg"
```

### Step 5: Report to user
Tell the user:
- Which frame was selected and why
- What makes it a good thumbnail
- The output path
- Tips to improve it (e.g., add text overlay, brightness adjustment)

---

## WORKFLOW E — GITHUB THUMBNAIL UPLOAD

When user wants to upload thumbnail to GitHub:

### Step 1: Collect information
Ask:
```
To upload your thumbnail to GitHub, I need:
1. Your GitHub Personal Access Token (with repo scope)
2. Repository name (e.g., myusername/my-thumbnails)
3. A filename for the thumbnail (e.g., video-thumbnail-march-2026.jpg)

Please provide these details.
```

**IMPORTANT**: Never store or log the GitHub token. Use it only for the single upload operation.

### Step 2: Run upload script
```bash
python scripts/github_upload.py \
  --token "GITHUB_TOKEN" \
  --repo "USERNAME/REPO" \
  --file "thumbnail.jpg" \
  --filename "thumbnails/thumbnail-NAME.jpg" \
  --message "Add thumbnail - created by Akshay Bhimani"
```

### Step 3: Provide public URL
After upload, provide the raw GitHub URL:
```
https://raw.githubusercontent.com/USERNAME/REPO/main/thumbnails/FILENAME.jpg
```

---

## ERROR HANDLING

### FFmpeg not found
```
❌ FFmpeg not found at the expected path.
Expected: C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe

Fix options:
1. Verify FFmpeg is extracted at that location
2. Run: scripts\install.bat to set up the environment
3. Or set FFMPEG_PATH environment variable to your FFmpeg location
```

### Video codec mismatch during merge
Use `-c:v libx264 -c:a aac` instead of `-c copy` to re-encode all clips to the same codec.

### Output too large
Add `-crf 28` (higher = smaller file, lower quality) or reduce bitrate:
```bash
-b:v 4000k
```

### Permission denied on output file
Close any video player that has the file open, then retry.

---

## TIPS FOR CREATORS

- **Best thumbnail frames**: Usually 30–60% into the video (climax/peak moment)
- **Thumbnail text**: Keep it under 6 words, large font, high contrast
- **Reels optimal length**: 15–30 seconds for highest reach
- **YouTube Shorts**: Must be under 60 seconds and vertical (9:16)
- **TikTok**: Add trending audio for more reach — this plugin handles video only
- **File size limits**: Instagram 4GB, YouTube 256GB, TikTok 287.6MB

---

## FULL WORKFLOW EXAMPLE

User uploads `raw_video.mp4` and wants an Instagram Reel with thumbnail:

1. Detect video info with ffprobe
2. Trim to best 30-second segment (ask user or auto-detect)
3. Export as 1080x1920 vertical MP4
4. Extract frames from the trimmed video
5. Analyse frames → select best for thumbnail
6. Generate 1080x1920 thumbnail from best frame
7. Ask about GitHub upload
8. Deliver: `output_reel.mp4` + `thumbnail_reel.jpg`

---

*Video Creator Plugin v1.0.0 — Created by Akshay Bhimani*
*FFmpeg path: C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\*
