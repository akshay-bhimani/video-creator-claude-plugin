#!/bin/bash
# ============================================================
#  Video Creator Plugin — Installer (macOS / Linux)
#  Created by Akshay Bhimani
#  Version: 1.0.0
# ============================================================

echo ""
echo " ========================================================"
echo "  Video Creator Plugin v1.0.0 — Installer"
echo "  Created by Akshay Bhimani"
echo " ========================================================"
echo ""

# ── Python check ──────────────────────────────────────────────
echo "[1/4] Checking Python..."
if command -v python3 &>/dev/null; then
    echo "  Found: $(python3 --version)"
    echo "  Installing Pillow..."
    python3 -m pip install Pillow --quiet && echo "  Pillow OK" || echo "  WARNING: Pillow install failed"
else
    echo "  WARNING: Python3 not found. Thumbnail text overlays disabled."
fi
echo ""

# ── FFmpeg check ──────────────────────────────────────────────
echo "[2/4] Checking FFmpeg..."
if command -v ffmpeg &>/dev/null; then
    echo "  Found: $(ffmpeg -version 2>&1 | head -1)"
    echo "  OK"
else
    echo "  WARNING: FFmpeg not found."
    echo "  macOS:  brew install ffmpeg"
    echo "  Ubuntu: sudo apt install ffmpeg"
fi
echo ""

# ── Find plugins folder ───────────────────────────────────────
echo "[3/4] Finding Claude plugins folder..."
PLUGIN_BASE=""
if [ -d "$HOME/.config/Claude/plugins" ]; then
    PLUGIN_BASE="$HOME/.config/Claude/plugins"
elif [ -d "$HOME/Library/Application Support/Claude/plugins" ]; then
    PLUGIN_BASE="$HOME/Library/Application Support/Claude/plugins"
elif [ -d "$HOME/.claude/plugins" ]; then
    PLUGIN_BASE="$HOME/.claude/plugins"
else
    PLUGIN_BASE="$HOME/.claude/plugins"
    mkdir -p "$PLUGIN_BASE"
    echo "  Created: $PLUGIN_BASE"
fi
PLUGIN_DIR="$PLUGIN_BASE/video-creator"
echo "  Target: $PLUGIN_DIR"
echo ""

# ── Install files ─────────────────────────────────────────────
echo "[4/4] Copying plugin files..."
rm -rf "$PLUGIN_DIR"
cp -r "$(dirname "$0")" "$PLUGIN_DIR"
echo "  Done!"
echo ""

echo " ========================================================"
echo "  Installation Complete!"
echo " ========================================================"
echo ""
echo "  Next steps:"
echo "   1. Restart Claude Code"
echo "   2. Type /video-creator in the chat"
echo "   3. Upload a video and follow Claude's prompts"
echo ""
echo "  Created by Akshay Bhimani"
echo " ========================================================"
echo ""
