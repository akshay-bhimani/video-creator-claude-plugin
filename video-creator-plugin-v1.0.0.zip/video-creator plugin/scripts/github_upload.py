#!/usr/bin/env python3
"""
GitHub Thumbnail Uploader — Video Creator Plugin
Created by Akshay Bhimani
Version: 1.0.0

Uploads generated thumbnails to a GitHub repository for public sharing.
Uses the GitHub REST API (no git required).
"""

import os
import sys
import json
import base64
import urllib.request
import urllib.error
import argparse
from pathlib import Path

CREATED_BY = "Akshay Bhimani"
GITHUB_API = "https://api.github.com"


def upload_to_github(token, repo, local_file, remote_path, commit_message=None):
    """
    Upload a file to GitHub via the Contents API.

    Args:
        token:          GitHub Personal Access Token (repo scope)
        repo:           'username/repo-name'
        local_file:     Path to the local file to upload
        remote_path:    Path in the repo (e.g. 'thumbnails/thumb.jpg')
        commit_message: Git commit message

    Returns:
        (success: bool, public_url: str or None)
    """
    if not os.path.isfile(local_file):
        print(f"❌ File not found: {local_file}")
        return False, None

    # Read and encode file
    with open(local_file, "rb") as f:
        content = base64.b64encode(f.read()).decode("utf-8")

    if not commit_message:
        commit_message = (
            f"Add thumbnail: {os.path.basename(local_file)} "
            f"— created by {CREATED_BY}"
        )

    # Check if file already exists (needed to get SHA for update)
    url = f"{GITHUB_API}/repos/{repo}/contents/{remote_path}"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "Content-Type": "application/json",
        "User-Agent": f"video-creator-plugin/{CREATED_BY}",
    }

    sha = None
    try:
        req = urllib.request.Request(url, headers=headers, method="GET")
        with urllib.request.urlopen(req) as resp:
            existing = json.loads(resp.read().decode())
            sha = existing.get("sha")
            print(f"  ℹ️  File exists — will update (SHA: {sha[:8]}...)")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            print(f"  ℹ️  File does not exist — will create")
        else:
            print(f"❌ GitHub API error checking file: {e.code} {e.reason}")
            return False, None
    except Exception as e:
        print(f"❌ Error connecting to GitHub: {e}")
        return False, None

    # Build payload
    payload = {
        "message": commit_message,
        "content": content,
        "committer": {
            "name": CREATED_BY,
            "email": "video-creator-plugin@github.com"
        }
    }
    if sha:
        payload["sha"] = sha

    # Upload
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="PUT")
        with urllib.request.urlopen(req) as resp:
            result = json.loads(resp.read().decode())

        download_url = result.get("content", {}).get("download_url", "")
        html_url = result.get("content", {}).get("html_url", "")
        raw_url = download_url or (
            f"https://raw.githubusercontent.com/{repo}/main/{remote_path}"
        )

        print(f"\n✅ Upload successful!")
        print(f"   File:     {os.path.basename(local_file)}")
        print(f"   Repo:     {repo}")
        print(f"   Path:     {remote_path}")
        print(f"   Raw URL:  {raw_url}")
        print(f"   View:     {html_url}")
        print(f"\n📋 Copy this public URL to share your thumbnail:")
        print(f"   {raw_url}\n")

        return True, raw_url

    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        print(f"❌ GitHub API error: {e.code} {e.reason}")
        print(f"   Details: {body[:300]}")
        if e.code == 401:
            print("   → Token invalid or expired. Generate a new one at:")
            print("     https://github.com/settings/tokens")
        elif e.code == 422:
            print("   → Unprocessable entity. Check repo name and remote path.")
        return False, None
    except Exception as e:
        print(f"❌ Upload failed: {e}")
        return False, None


def validate_token(token, repo):
    """Quick check that the token has access to the repo."""
    url = f"{GITHUB_API}/repos/{repo}"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": f"video-creator-plugin/{CREATED_BY}",
    }
    try:
        req = urllib.request.Request(url, headers=headers, method="GET")
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode())
            print(f"  ✅ Token valid — repo: {data.get('full_name')} "
                  f"({'private' if data.get('private') else 'public'})")
            return True
    except urllib.error.HTTPError as e:
        if e.code == 401:
            print("❌ Invalid GitHub token.")
        elif e.code == 404:
            print(f"❌ Repo not found or no access: {repo}")
        else:
            print(f"❌ GitHub error: {e.code}")
        return False
    except Exception as e:
        print(f"❌ Connection error: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(
        description=f"GitHub Thumbnail Uploader — by {CREATED_BY}"
    )
    parser.add_argument("--token", required=True,
                        help="GitHub Personal Access Token (repo scope)")
    parser.add_argument("--repo", required=True,
                        help="GitHub repo (e.g. username/my-thumbnails)")
    parser.add_argument("--file", required=True,
                        help="Local file to upload")
    parser.add_argument("--filename", default=None,
                        help="Remote path in repo (default: thumbnails/<basename>)")
    parser.add_argument("--message", default=None,
                        help="Commit message")
    parser.add_argument("--validate-only", action="store_true",
                        help="Only validate token/repo, don't upload")

    args = parser.parse_args()

    print(f"\n📤 GitHub Uploader — by {CREATED_BY}\n")

    remote_path = args.filename or f"thumbnails/{Path(args.file).name}"

    # Validate first
    print(f"  Validating token & repo...")
    if not validate_token(args.token, args.repo):
        sys.exit(1)

    if args.validate_only:
        print("  Validation successful. Exiting (--validate-only).")
        sys.exit(0)

    print(f"\n  Uploading: {args.file}")
    print(f"  To:        {args.repo}/{remote_path}")

    success, url = upload_to_github(
        token=args.token,
        repo=args.repo,
        local_file=args.file,
        remote_path=remote_path,
        commit_message=args.message,
    )

    if not success:
        sys.exit(1)


if __name__ == "__main__":
    main()
