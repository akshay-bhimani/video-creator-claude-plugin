#!/usr/bin/env python3
"""
Video Processor — Video Creator Plugin
Created by Akshay Bhimani
Version: 1.0.0

Handles: merge, trim, export for social platforms, frame extraction
Uses FFmpeg for all video operations.
"""

import os
import sys
import json
import shutil
import subprocess
import argparse
import tempfile
from pathlib import Path

# ─── CONFIGURATION ────────────────────────────────────────────────────────────

FFMPEG_PATH = os.environ.get(
    "FFMPEG_PATH",
    r"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe"
)
FFPROBE_PATH = os.environ.get(
    "FFPROBE_PATH",
    r"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffprobe.exe"
)

CREATED_BY = "Akshay Bhimani"
PLUGIN_VERSION = "1.0.0"

# ─── PLATFORM PRESETS ─────────────────────────────────────────────────────────

PLATFORM_PRESETS = {
    "instagram_reels": {
        "width": 1080, "height": 1920, "fps": 30,
        "vbitrate": "8000k", "abitrate": "128k",
        "max_duration": 60, "label": "Instagram Reels"
    },
    "tiktok": {
        "width": 1080, "height": 1920, "fps": 30,
        "vbitrate": "8000k", "abitrate": "128k",
        "max_duration": 60, "label": "TikTok"
    },
    "youtube_shorts": {
        "width": 1080, "height": 1920, "fps": 30,
        "vbitrate": "8000k", "abitrate": "128k",
        "max_duration": 60, "label": "YouTube Shorts"
    },
    "youtube": {
        "width": 1920, "height": 1080, "fps": 30,
        "vbitrate": "8000k", "abitrate": "192k",
        "max_duration": None, "label": "YouTube"
    },
    "facebook_reels": {
        "width": 1080, "height": 1920, "fps": 30,
        "vbitrate": "6000k", "abitrate": "128k",
        "max_duration": 60, "label": "Facebook Reels"
    },
    "twitter": {
        "width": 1280, "height": 720, "fps": 30,
        "vbitrate": "5000k", "abitrate": "128k",
        "max_duration": 140, "label": "Twitter/X"
    },
    "generic": {
        "width": None, "height": None, "fps": 30,
        "vbitrate": "6000k", "abitrate": "128k",
        "max_duration": None, "label": "Generic MP4"
    },
}

# ─── HELPERS ──────────────────────────────────────────────────────────────────

def check_ffmpeg():
    """Verify FFmpeg is available."""
    if os.path.isfile(FFMPEG_PATH):
        return FFMPEG_PATH
    result = shutil.which("ffmpeg")
    if result:
        return result
    print(f"ERROR: FFmpeg not found.\n"
          f"  Expected: {FFMPEG_PATH}\n"
          f"  Install FFmpeg or set FFMPEG_PATH environment variable.")
    sys.exit(1)


def run_ffmpeg(args, description=""):
    """Run an FFmpeg command and return success/failure."""
    cmd = [check_ffmpeg()] + args
    print(f"\n{'─'*60}")
    if description:
        print(f"▶  {description}")
    print(f"   CMD: {' '.join(cmd)}")
    print(f"{'─'*60}")

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"❌ FFmpeg error:\n{result.stderr}")
        return False
    print(f"✅ Done: {description or 'FFmpeg command'}")
    return True


def probe_video(filepath):
    """Get video metadata using ffprobe."""
    probe = FFPROBE_PATH if os.path.isfile(FFPROBE_PATH) else "ffprobe"
    cmd = [
        probe, "-v", "error",
        "-select_streams", "v:0",
        "-show_entries", "stream=width,height,r_frame_rate,duration,codec_name",
        "-show_entries", "format=duration,size",
        "-of", "json", filepath
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        return None
    return json.loads(result.stdout)


def ensure_dir(path):
    """Create directory if it doesn't exist."""
    Path(path).mkdir(parents=True, exist_ok=True)


# ─── MERGE ────────────────────────────────────────────────────────────────────

def merge_clips(input_files, output_file, reencode=False):
    """
    Merge multiple video clips into one.
    - input_files: list of file paths
    - output_file: output path
    - reencode: if True, re-encode to ensure compatibility
    """
    if len(input_files) < 2:
        print("ERROR: Need at least 2 files to merge.")
        return False

    # Validate inputs
    for f in input_files:
        if not os.path.isfile(f):
            print(f"ERROR: File not found: {f}")
            return False

    # Write concat list
    concat_file = tempfile.NamedTemporaryFile(
        mode='w', suffix='.txt', delete=False, encoding='utf-8'
    )
    for f in input_files:
        concat_file.write(f"file '{f.replace(chr(92), '/')}'\n")
    concat_file.close()

    print(f"\n📋 Merging {len(input_files)} clips:")
    for i, f in enumerate(input_files, 1):
        print(f"   {i}. {os.path.basename(f)}")

    ensure_dir(os.path.dirname(output_file) or '.')

    if reencode:
        args = [
            "-f", "concat", "-safe", "0", "-i", concat_file.name,
            "-vf", "scale=1080:1920:force_original_aspect_ratio=decrease,"
                   "pad=1080:1920:(ow-iw)/2:(oh-ih)/2:color=black",
            "-c:v", "libx264", "-preset", "fast", "-crf", "23",
            "-c:a", "aac", "-b:a", "128k",
            "-movflags", "+faststart",
            "-y", output_file
        ]
    else:
        args = [
            "-f", "concat", "-safe", "0", "-i", concat_file.name,
            "-c", "copy",
            "-movflags", "+faststart",
            "-y", output_file
        ]

    success = run_ffmpeg(args, f"Merging clips → {os.path.basename(output_file)}")
    os.unlink(concat_file.name)
    return success


# ─── TRIM ─────────────────────────────────────────────────────────────────────

def trim_video(input_file, output_file, start_time, end_time=None, duration=None, reencode=False):
    """
    Trim a video to a specific time range.
    - start_time: seconds or HH:MM:SS
    - end_time: seconds or HH:MM:SS (optional if duration is set)
    - duration: length in seconds (alternative to end_time)
    """
    if not os.path.isfile(input_file):
        print(f"ERROR: File not found: {input_file}")
        return False

    ensure_dir(os.path.dirname(output_file) or '.')

    args = ["-ss", str(start_time)]
    if duration:
        args += ["-t", str(duration)]
    elif end_time:
        args += ["-to", str(end_time)]
    args += ["-i", input_file]

    if reencode:
        args += ["-c:v", "libx264", "-preset", "fast", "-crf", "23",
                 "-c:a", "aac", "-b:a", "128k"]
    else:
        args += ["-c", "copy"]

    args += ["-movflags", "+faststart", "-y", output_file]
    return run_ffmpeg(args, f"Trimming → {os.path.basename(output_file)}")


# ─── EXPORT FOR PLATFORM ──────────────────────────────────────────────────────

def export_for_platform(input_file, output_file, platform="instagram_reels"):
    """
    Export a video with platform-specific settings.
    """
    if not os.path.isfile(input_file):
        print(f"ERROR: File not found: {input_file}")
        return False

    preset = PLATFORM_PRESETS.get(platform, PLATFORM_PRESETS["generic"])
    print(f"\n🎯 Exporting for {preset['label']}")
    print(f"   Resolution: {preset['width']}x{preset['height']}")
    print(f"   FPS: {preset['fps']}, Bitrate: {preset['vbitrate']}")

    ensure_dir(os.path.dirname(output_file) or '.')

    if preset["width"] and preset["height"]:
        scale_filter = (
            f"scale={preset['width']}:{preset['height']}:"
            f"force_original_aspect_ratio=decrease,"
            f"pad={preset['width']}:{preset['height']}:(ow-iw)/2:(oh-ih)/2:color=black"
        )
        vf = ["-vf", scale_filter]
    else:
        vf = []

    args = (
        ["-i", input_file]
        + vf
        + ["-c:v", "libx264", "-preset", "fast", "-crf", "23",
           "-b:v", preset["vbitrate"],
           "-c:a", "aac", "-b:a", preset["abitrate"],
           "-r", str(preset["fps"]),
           "-movflags", "+faststart",
           "-y", output_file]
    )

    return run_ffmpeg(args, f"Exporting for {preset['label']}")


# ─── FRAME EXTRACTION ─────────────────────────────────────────────────────────

def extract_frames(input_file, output_dir, fps=0.5):
    """
    Extract frames from a video at a given rate.
    fps=0.5 → 1 frame every 2 seconds
    fps=1   → 1 frame per second
    """
    if not os.path.isfile(input_file):
        print(f"ERROR: File not found: {input_file}")
        return False

    ensure_dir(output_dir)
    pattern = os.path.join(output_dir, "frame_%04d.jpg")

    args = [
        "-i", input_file,
        "-vf", f"fps={fps}",
        "-q:v", "2",
        "-y", pattern
    ]

    success = run_ffmpeg(args, f"Extracting frames at {fps} fps → {output_dir}")
    if success:
        frames = sorted(Path(output_dir).glob("frame_*.jpg"))
        print(f"   Extracted {len(frames)} frames")
    return success


# ─── MAIN CLI ─────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description=f"Video Creator — by {CREATED_BY} v{PLUGIN_VERSION}"
    )
    subparsers = parser.add_subparsers(dest="command", help="Command")

    # merge
    merge_p = subparsers.add_parser("merge", help="Merge multiple clips")
    merge_p.add_argument("--inputs", nargs="+", required=True, help="Input video files")
    merge_p.add_argument("--output", required=True, help="Output file path")
    merge_p.add_argument("--reencode", action="store_true", help="Re-encode clips")

    # trim
    trim_p = subparsers.add_parser("trim", help="Trim a video")
    trim_p.add_argument("--input", required=True)
    trim_p.add_argument("--output", required=True)
    trim_p.add_argument("--start", required=True)
    trim_p.add_argument("--end", default=None)
    trim_p.add_argument("--duration", default=None)
    trim_p.add_argument("--reencode", action="store_true")

    # export
    export_p = subparsers.add_parser("export", help="Export for a platform")
    export_p.add_argument("--input", required=True)
    export_p.add_argument("--output", required=True)
    export_p.add_argument("--platform", default="instagram_reels",
                           choices=list(PLATFORM_PRESETS.keys()))

    # frames
    frames_p = subparsers.add_parser("frames", help="Extract frames")
    frames_p.add_argument("--input", required=True)
    frames_p.add_argument("--output-dir", required=True)
    frames_p.add_argument("--fps", type=float, default=0.5)

    # probe
    probe_p = subparsers.add_parser("probe", help="Get video info")
    probe_p.add_argument("--input", required=True)

    args = parser.parse_args()

    print(f"\n🎬 Video Creator Plugin v{PLUGIN_VERSION} — by {CREATED_BY}\n")

    if args.command == "merge":
        success = merge_clips(args.inputs, args.output, args.reencode)
    elif args.command == "trim":
        success = trim_video(args.input, args.output, args.start,
                              args.end, args.duration, args.reencode)
    elif args.command == "export":
        success = export_for_platform(args.input, args.output, args.platform)
    elif args.command == "frames":
        success = extract_frames(args.input, args.output_dir, args.fps)
    elif args.command == "probe":
        info = probe_video(args.input)
        if info:
            print(json.dumps(info, indent=2))
            success = True
        else:
            print("ERROR: Could not probe video.")
            success = False
    else:
        parser.print_help()
        success = True

    if not success:
        sys.exit(1)


if __name__ == "__main__":
    main()
