@echo off
:: ============================================================
::  Video Creator Plugin — Installer
::  Created by Akshay Bhimani
::  Version: 1.0.0
:: ============================================================

title Video Creator Plugin Installer

echo.
echo  ========================================================
echo   Video Creator Plugin v1.0.0 — Installer
echo   Created by Akshay Bhimani
echo  ========================================================
echo.

:: ── STEP 1: Check Python ─────────────────────────────────────
echo [1/5] Checking Python...
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo  WARNING: Python not found in PATH.
    echo  Python is optional but needed for thumbnail scripts.
    echo  Download from: https://python.org/downloads
    echo.
) else (
    for /f "tokens=*" %%v in ('python --version 2^>^&1') do echo  Found: %%v
    echo  OK
    echo.

    :: ── STEP 2: Install Python dependencies ─────────────────
    echo [2/5] Installing Python dependencies...
    python -m pip install Pillow --quiet
    if %ERRORLEVEL% EQU 0 (
        echo  Pillow installed - text overlays enabled
    ) else (
        echo  WARNING: Pillow install failed - text overlays disabled
        echo  (thumbnails will still work without text)
    )
    echo.
)

:: ── STEP 3: Check FFmpeg ─────────────────────────────────────
echo [3/5] Checking FFmpeg...
set FFMPEG_DEFAULT=C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe

if exist "%FFMPEG_DEFAULT%" (
    echo  Found FFmpeg at default location:
    echo  %FFMPEG_DEFAULT%
    echo  Setting FFMPEG_PATH for this session...
    setx FFMPEG_PATH "%FFMPEG_DEFAULT%" /M >nul 2>&1
    set FFMPEG_PATH=%FFMPEG_DEFAULT%
    echo  OK
) else (
    ffmpeg -version >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        echo  FFmpeg found in global PATH
        echo  OK
    ) else (
        echo  WARNING: FFmpeg not found at:
        echo  %FFMPEG_DEFAULT%
        echo.
        echo  Please install FFmpeg from: https://ffmpeg.org/download.html
        echo  Then set: FFMPEG_PATH=C:\path\to\ffmpeg.exe
    )
)
echo.

:: ── STEP 4: Find Claude plugins folder ───────────────────────
echo [4/5] Finding Claude Code plugins folder...

set CLAUDE_PLUGINS=%APPDATA%\Claude\plugins
set CLAUDE_PLUGINS_ALT=%USERPROFILE%\.claude\plugins

if exist "%CLAUDE_PLUGINS%" (
    set PLUGIN_DIR=%CLAUDE_PLUGINS%\video-creator
    echo  Found: %CLAUDE_PLUGINS%
) else if exist "%CLAUDE_PLUGINS_ALT%" (
    set PLUGIN_DIR=%CLAUDE_PLUGINS_ALT%\video-creator
    echo  Found: %CLAUDE_PLUGINS_ALT%
) else (
    echo  Creating: %CLAUDE_PLUGINS%
    mkdir "%CLAUDE_PLUGINS%" 2>nul
    set PLUGIN_DIR=%CLAUDE_PLUGINS%\video-creator
)
echo.

:: ── STEP 5: Copy plugin files ─────────────────────────────────
echo [5/5] Installing plugin to:
echo  %PLUGIN_DIR%

if exist "%PLUGIN_DIR%" (
    echo  Removing old version...
    rmdir /S /Q "%PLUGIN_DIR%"
)

mkdir "%PLUGIN_DIR%" 2>nul
xcopy /E /I /Q /Y "%~dp0*" "%PLUGIN_DIR%\" >nul 2>&1

if %ERRORLEVEL% EQU 0 (
    echo  Plugin files copied successfully!
) else (
    echo  ERROR: Could not copy files. Try running as Administrator.
    pause
    exit /b 1
)

:: ── DONE ──────────────────────────────────────────────────────
echo.
echo  ========================================================
echo   Installation Complete!
echo  ========================================================
echo.
echo  Next steps:
echo   1. Restart Claude Code (close and reopen)
echo   2. Type /video-creator in the chat to get started
echo   3. Upload a video and follow Claude's prompts
echo.
echo  Created by Akshay Bhimani
echo  ========================================================
echo.
pause
