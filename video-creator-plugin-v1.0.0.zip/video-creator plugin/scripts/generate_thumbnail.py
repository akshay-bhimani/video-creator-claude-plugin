#!/usr/bin/env python3
"""
Thumbnail Generator — Video Creator Plugin
Created by Akshay Bhimani
Version: 1.0.0

Extracts frames, selects the best one, and generates a platform-ready thumbnail.
Works with or without Pillow (falls back to FFmpeg-only mode).
"""

import os
import sys
import json
import shutil
import subprocess
import argparse
from pathlib import Path

# ─── CONFIG ───────────────────────────────────────────────────────────────────

FFMPEG_PATH = os.environ.get(
    "FFMPEG_PATH",
    r"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe"
)
FFPROBE_PATH = os.environ.get(
    "FFPROBE_PATH",
    r"C:\Users\BAPS\Downloads\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffprobe.exe"
)

CREATED_BY = "Akshay Bhimani"

THUMBNAIL_SIZES = {
    "youtube":          (1280, 720),
    "instagram_reels":  (1080, 1920),
    "tiktok":           (1080, 1920),
    "youtube_shorts":   (1080, 1920),
    "instagram_post":   (1080, 1080),
    "facebook":         (1200, 630),
    "twitter":          (1280, 720),
    "generic":          (1280, 720),
}

# ─── HELPERS ──────────────────────────────────────────────────────────────────

def ffmpeg():
    if os.path.isfile(FFMPEG_PATH):
        return FFMPEG_PATH
    found = shutil.which("ffmpeg")
    if found:
        return found
    print(f"ERROR: FFmpeg not found at {FFMPEG_PATH}")
    sys.exit(1)


def ffprobe():
    if os.path.isfile(FFPROBE_PATH):
        return FFPROBE_PATH
    found = shutil.which("ffprobe")
    if found:
        return found
    return None


def run(cmd, label=""):
    print(f"  ▶ {label or cmd[0]}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  ❌ Error: {result.stderr[-300:]}")
        return False
    return True


def get_duration(video_path):
    """Get video duration in seconds."""
    probe = ffprobe()
    if not probe:
        return None
    cmd = [
        probe, "-v", "error",
        "-show_entries", "format=duration",
        "-of", "json", video_path
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        data = json.loads(result.stdout)
        return float(data.get("format", {}).get("duration", 0))
    return None


# ─── FRAME EXTRACTION ─────────────────────────────────────────────────────────

def extract_candidate_frames(video_path, frames_dir, count=20):
    """
    Extract 'count' evenly-spaced frames from the video.
    Focuses on the middle 60% of the video (skips intro/outro).
    Returns list of frame file paths.
    """
    os.makedirs(frames_dir, exist_ok=True)

    duration = get_duration(video_path)
    if not duration:
        # Fallback: extract at 0.5fps
        cmd = [
            ffmpeg(), "-i", video_path,
            "-vf", "fps=0.5", "-q:v", "2", "-y",
            os.path.join(frames_dir, "frame_%04d.jpg")
        ]
        run(cmd, "Extracting frames (fallback)")
    else:
        # Extract from 20%–80% of duration
        start = duration * 0.20
        end = duration * 0.80
        segment = end - start
        interval = segment / count

        print(f"  📹 Duration: {duration:.1f}s — extracting {count} candidate frames")

        for i in range(count):
            ts = start + (i * interval)
            out = os.path.join(frames_dir, f"frame_{i+1:04d}.jpg")
            cmd = [
                ffmpeg(), "-ss", str(ts), "-i", video_path,
                "-frames:v", "1", "-q:v", "2", "-y", out
            ]
            subprocess.run(cmd, capture_output=True)

    frames = sorted(Path(frames_dir).glob("frame_*.jpg"))
    print(f"  ✅ Extracted {len(frames)} candidate frames")
    return [str(f) for f in frames]


# ─── FRAME SCORING ────────────────────────────────────────────────────────────

def score_frame_ffmpeg(frame_path):
    """
    Score a frame using FFmpeg's signalstats filter.
    Higher YAVG (brightness) and lower YDIF (blur) = better frame.
    Returns a score (higher is better).
    """
    probe = ffprobe()
    if not probe:
        return 0.5  # neutral score if ffprobe unavailable

    cmd = [
        ffmpeg(), "-i", frame_path,
        "-vf", "signalstats,metadata=print:file=-",
        "-frames:v", "1", "-f", "null", "-"
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, stderr=subprocess.STDOUT)
    output = result.stderr + result.stdout

    yavg = 0.5
    ydif = 0.5

    for line in output.splitlines():
        if "lavfi.signalstats.YAVG" in line:
            try:
                yavg = float(line.split("=")[1]) / 255.0
            except Exception:
                pass
        if "lavfi.signalstats.YDIF" in line:
            try:
                ydif = float(line.split("=")[1]) / 255.0
            except Exception:
                pass

    # Score: prefer bright (not too dark, not blown out) and sharp (low diff = blurry)
    brightness_score = 1.0 - abs(yavg - 0.5) * 2  # peaks at 0.5 brightness
    sharpness_score = min(ydif * 5, 1.0)            # higher diff = more detail
    score = (brightness_score * 0.4) + (sharpness_score * 0.6)
    return score


def select_best_frame(frames):
    """
    Score all candidate frames and return the best one.
    """
    if not frames:
        return None

    print(f"\n  🔍 Analysing {len(frames)} frames for best thumbnail...")
    scored = []
    for i, frame in enumerate(frames):
        score = score_frame_ffmpeg(frame)
        scored.append((score, frame))
        if (i + 1) % 5 == 0:
            print(f"    Scored {i+1}/{len(frames)} frames...")

    scored.sort(reverse=True)
    best_score, best_frame = scored[0]
    print(f"  🏆 Best frame: {os.path.basename(best_frame)} (score: {best_score:.3f})")
    return best_frame


# ─── THUMBNAIL GENERATION ─────────────────────────────────────────────────────

def generate_thumbnail(best_frame, output_path, platform="youtube", title=None):
    """
    Crop and resize the best frame to platform thumbnail dimensions.
    Optionally overlays a title if Pillow is available.
    """
    size = THUMBNAIL_SIZES.get(platform, THUMBNAIL_SIZES["generic"])
    w, h = size

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    # Resize with padding
    scale_filter = (
        f"scale={w}:{h}:force_original_aspect_ratio=decrease,"
        f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:color=black"
    )

    cmd = [
        ffmpeg(), "-i", best_frame,
        "-vf", scale_filter,
        "-q:v", "1",
        "-y", output_path
    ]
    success = run(cmd, f"Generating {w}x{h} thumbnail for {platform}")
    if not success:
        return False

    # Try to add title overlay using Pillow (optional)
    if title:
        try:
            _add_title_overlay(output_path, title, w, h)
        except ImportError:
            print("  ℹ️  Pillow not installed — skipping text overlay")
            print("     Install with: pip install Pillow")
        except Exception as e:
            print(f"  ⚠️  Text overlay failed: {e}")

    print(f"  ✅ Thumbnail saved: {output_path}")
    return True


def _add_title_overlay(image_path, title, width, height):
    """Add a semi-transparent title bar at the bottom of the thumbnail."""
    from PIL import Image, ImageDraw, ImageFont
    import textwrap

    img = Image.open(image_path).convert("RGBA")

    # Semi-transparent bottom bar
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    bar_height = int(height * 0.18)
    draw.rectangle(
        [(0, height - bar_height), (width, height)],
        fill=(0, 0, 0, 180)
    )

    # Try to load a font
    font = None
    font_size = max(30, width // 24)
    for font_path in [
        "C:/Windows/Fonts/arialbd.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    ]:
        if os.path.isfile(font_path):
            try:
                font = ImageFont.truetype(font_path, font_size)
                break
            except Exception:
                pass

    if font is None:
        font = ImageFont.load_default()

    # Wrap and draw text
    wrapped = textwrap.fill(title, width=max(20, width // font_size))
    text_draw = ImageDraw.Draw(overlay)
    text_draw.text(
        (width * 0.05, height - bar_height + bar_height * 0.2),
        wrapped, font=font, fill=(255, 255, 255, 255)
    )

    combined = Image.alpha_composite(img, overlay).convert("RGB")
    combined.save(image_path, quality=95)
    print(f"  🖊️  Title overlay added: '{title}'")


# ─── MAIN ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description=f"Thumbnail Generator — by {CREATED_BY}"
    )
    parser.add_argument("--video", help="Input video file")
    parser.add_argument("--frame", help="Use this specific frame (skip extraction)")
    parser.add_argument("--frames-dir", default="frames_temp", help="Directory for extracted frames")
    parser.add_argument("--output", default="thumbnail.jpg", help="Output thumbnail path")
    parser.add_argument("--platform", default="youtube",
                        choices=list(THUMBNAIL_SIZES.keys()),
                        help="Target platform")
    parser.add_argument("--title", default=None, help="Optional title overlay text")
    parser.add_argument("--frame-count", type=int, default=20,
                        help="Number of candidate frames to extract (default: 20)")
    parser.add_argument("--keep-frames", action="store_true", dest="keep_frames",
                        help="Keep extracted frames after processing")

    args = parser.parse_args()

    print(f"\n🖼️  Thumbnail Generator — by {CREATED_BY}\n")

    if args.frame:
        # Use provided frame directly
        if not os.path.isfile(args.frame):
            print(f"ERROR: Frame not found: {args.frame}")
            sys.exit(1)
        best_frame = args.frame
        print(f"  Using provided frame: {args.frame}")
    elif args.video:
        # Extract and select best frame
        if not os.path.isfile(args.video):
            print(f"ERROR: Video not found: {args.video}")
            sys.exit(1)

        frames = extract_candidate_frames(args.video, args.frames_dir, args.frame_count)
        if not frames:
            print("ERROR: No frames extracted.")
            sys.exit(1)

        best_frame = select_best_frame(frames)
        if not best_frame:
            print("ERROR: Could not select best frame.")
            sys.exit(1)
    else:
        print("ERROR: Provide --video or --frame")
        parser.print_help()
        sys.exit(1)

    success = generate_thumbnail(best_frame, args.output, args.platform, args.title)

    # Cleanup frames
    if args.video and not args.keep_frames and os.path.isdir(args.frames_dir):
        shutil.rmtree(args.frames_dir, ignore_errors=True)
        print(f"  🗑️  Cleaned up temp frames")

    if not success:
        sys.exit(1)

    print(f"\n✅ Thumbnail ready: {args.output}")
    print(f"   Platform: {args.platform} — {THUMBNAIL_SIZES[args.platform]}")
    print(f"   Created by: {CREATED_BY}")


if __name__ == "__main__":
    main()
